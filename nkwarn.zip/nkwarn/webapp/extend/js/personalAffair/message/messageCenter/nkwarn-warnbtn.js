/*
 * 内控二开 - 消息中心"预警参数设置"按钮
 * ------------------------------------------------------------------
 * 目标：在"消息中心"(/message.do?method=messageCenter) 顶部工具栏，
 *       跟"导出记录/清空所有消息/全部标记为已读"并排，增加一个
 *       "预警参数设置"按钮。选中左侧某个"表单模板"分类(如 发票登记单)
 *       时点击，跳到该表单的"业务关系"页配置预警(=本表触发消息)：
 *         - 已有本表触发关系 → 打开列表(view)，让用户自己改；
 *         - 没有            → 直接打开新建触发(new)。
 *       选中的是系统分类(全部/未读/@我的…)时，按钮置灰。
 *
 * 无侵入：本文件通过平台 extend/js 机制自动注入到消息中心页，
 *         不修改 A8 任何源码/JSP/JS。视图名 = personalAffair/message/messageCenter。
 *
 * 依赖(均为消息中心页已加载的平台能力)：
 *   - jQuery、$.ctx.CurrentUser({id,loginAccount,isAdmin,name})
 *   - callBackendMethod(manager, method, ...args) 同步网关
 *   - 页面全局：selected(当前选中分类li的id)、changeCategory(id)、_ctxPath
 *   - 工具栏组件：$("#toolbar").attrObj("toolbarObj").addMenu(...)
 */
(function () {
    "use strict";

    if (window.__nkWarnBtnLoaded) { return; }   // 防重复注入
    window.__nkWarnBtnLoaded = true;

    var BTN_ID = "nkWarnBtn";
    var BTN_NAME = "预警参数设置";
    var ROLE_DESIGNER = "BusinessDesigner";      // 系统角色：应用设计师
    var TIP_NO_FORM = "请先在左侧选择一个表单分类。";

    function log() {
        try {
            if (window.console && console.log) {
                console.log.apply(console, ["[nkwarn]"].concat([].slice.call(arguments)));
            }
        } catch (e) { /* ignore */ }
    }

    function tip(msg) {
        try { if ($.alert) { $.alert(msg); return; } } catch (e) { /* ignore */ }
        alert(msg);
    }

    /* 当前选中分类的 li（页面全局 selected 存的是该 li 的 id） */
    function selectedLi() {
        var sel = window.selected;
        if (!sel) { return null; }
        var $li = $("#" + sel);
        return $li.length ? $li : null;
    }

    /*
     * 读取当前选中分类信息。
     * c=="t" 表示"按表单模板过滤"的分类，隐藏域 input_<id> 里是模板ID
     * (模板分类时是逗号分隔的多个，取第一个)。
     */
    function currentTemplateInfo() {
        var $li = selectedLi();
        if (!$li) { return null; }
        if ($li.attr("c") !== "t") { return { isTemplate: false }; }
        var raw = ($("#input_" + $li.attr("id")).val() || $li.attr("c-id") || "").trim();
        var templateId = raw.split(",")[0];
        var name = ($li.find("span").attr("title") || "").trim();
        return { isTemplate: true, templateId: templateId, name: name };
    }

    /* 权限：仅应用设计师(或管理员)可见 */
    function isDesigner() {
        try {
            var cu = $.ctx && $.ctx.CurrentUser;
            if (!cu) { return false; }
            if (cu.isAdmin) { return true; }
            var members = callBackendMethod("capBizManager", "getMembersByRole", cu.loginAccount, ROLE_DESIGNER);
            if (!members || !members.length) { return false; }
            for (var i = 0; i < members.length; i++) {
                if (String(members[i].id) === String(cu.id)) { return true; }
            }
            return false;
        } catch (e) {
            log("角色判断异常，按无权限处理", e);
            return false;
        }
    }

    /* 点击：解析模板→表单，判断本表触发有无，跳转业务关系页 */
    function doJump() {
        var info = currentTemplateInfo();
        if (!info || !info.isTemplate) { tip(TIP_NO_FORM); return; }

        var templateId = info.templateId;
        if (!templateId) { tip(TIP_NO_FORM); return; }

        // 1) 模板ID → CAP4 表单ID(formAppId)，并确认确为 CAP4 表单
        var formId = null, isCap4 = false;
        try {
            var tpl = callBackendMethod("templateManager", "getCtpTemplate", templateId);
            formId = tpl && (tpl.formAppId || tpl.formId);
            isCap4 = callBackendMethod("templateManager", "isCap4Template", templateId);
        } catch (e) { log("模板解析异常", e); }

        if (!formId || !isCap4) {
            tip("该分类对应的不是 CAP4 表单，无法配置预警参数。");
            return;
        }

        // 2) 该表单是否已有"本表关系"(业务关系设置左侧列表：关联 或 触发 任一有)
        //    调用约定完全照搬产品自身 bizconfigRelation.js.jsp:217 initInnerTree()：
        //      - 入参是 {sourceFormId: formId} 对象，不是位置参数
        //      - 返回 obj.relationship 是 JSON 字符串，需 parse 后才有 relationList/triggerList
        var hasRelation = false;
        try {
            var res = callBackendMethod("cap4FormInnerBusinessManager", "getFormInnerBusiness",
                                        { sourceFormId: formId });
            if (res && (res.success === true || res.success === "true") && res.relationship) {
                var map = ($.parseJSON ? $.parseJSON(res.relationship) : JSON.parse(res.relationship)) || {};
                var nRelation = (map.relationList || []).length;
                var nTrigger = (map.triggerList || []).length;
                hasRelation = (nRelation + nTrigger) > 0;
                log("本表关系数量", { 关联: nRelation, 触发: nTrigger, 判定为有关系: hasRelation });
            } else {
                log("!! getFormInnerBusiness 返回不符合预期，按『无关系』处理，原始返回=", res);
            }
        } catch (e) {
            log("!! 查询本表关系抛异常，按『无关系』处理：", e);
        }

        // 3) 拼 URL：本表关系(mainFormId==subFormId)。bizConfigId 省略=从表单管理进入(官方允许)
        //    有关系 → view(打开左侧列表，用户自己选着改)；没有 → new(直接开新建触发)
        var enc = encodeURI(info.name || "");
        var url = _ctxPath + "/cap4/business.do?method=bizConfigRelation"
            + "&subFormId=" + formId + "&mainFormId=" + formId
            + "&subFormTitle=" + enc + "&mainFormTitle=" + enc
            + "&mainFormType=1&mainFormType=6"
            + (hasRelation ? "&relationType=&operationType=view"
                           : "&relationType=trigger&operationType=new");

        log("跳转", { templateId: templateId, formId: formId, hasRelation: hasRelation, url: url });
        window.open(url, "_blank");
    }

    /* 按钮置灰：非表单分类时半透明+提示 */
    function refreshBtnState() {
        var $a = $("#" + BTN_ID + "_a");
        if (!$a.length) { return; }
        var info = currentTemplateInfo();
        var enabled = !!(info && info.isTemplate);
        $a.css("opacity", enabled ? "" : "0.4");
        $a.attr("title", enabled ? BTN_NAME : TIP_NO_FORM);
        $a.data("nkEnabled", enabled);
    }

    /* 安装按钮到工具栏 */
    function installBtn() {
        var $tb = $("#toolbar");
        var bar = $tb.length && $tb.attrObj ? $tb.attrObj("toolbarObj") : null;
        if (!bar || !bar.addMenu) { return false; }         // 工具栏尚未初始化
        if ($("#" + BTN_ID + "_a").length) { return true; } // 已安装

        bar.addMenu({
            id: BTN_ID,
            name: BTN_NAME,
            className: "",
            click: function () {
                if ($("#" + BTN_ID + "_a").data("nkEnabled") === false) { tip(TIP_NO_FORM); return; }
                doJump();
            }
        });
        refreshBtnState();
        log("按钮已安装");
        return true;
    }

    /* 劫持 changeCategory：切换分类后刷新按钮置灰 */
    function hookChangeCategory() {
        if (window.__nkWarnHooked || typeof window.changeCategory !== "function") { return; }
        var orig = window.changeCategory;
        window.changeCategory = function () {
            var r = orig.apply(this, arguments);
            try { refreshBtnState(); } catch (e) { /* ignore */ }
            return r;
        };
        window.__nkWarnHooked = true;
    }

    /* 入口：DOM ready 后轮询等待工具栏就绪(最多 ~8s) */
    $(function () {
        if (!isDesigner()) { log("非应用设计师，不显示按钮"); return; }
        var tries = 0;
        var timer = setInterval(function () {
            tries++;
            if (installBtn() || tries > 40) {
                clearInterval(timer);
                hookChangeCategory();
            }
        }, 200);
    });
})();
