# nkwarn — 消息中心"预警参数设置"按钮

在致远 A8 消息中心（`/message.do?method=messageCenter`）顶部工具栏，跟"导出记录 / 清空所有消息 / 全部标记为已读"并排增加一个 **预警参数设置** 按钮。

## 功能

- 选中左侧某个**表单模板**分类（如"发票登记单"）时按钮可用；选中系统分类（全部/未读/@我的/领导的…）时按钮**置灰**并提示。
- 点击后跳到该表单的 **业务关系** 配置页（cap4，新标签页打开）：
  - 该表单**已有本表关系**（"业务关系设置"左侧列表里 **关联 或 触发** 任一有内容）→ 打开列表（`operationType=view`），用户自己选着改；
  - **一条都没有** → 直接打开新建触发（`operationType=new&relationType=trigger`）。
- 仅 **应用设计师（`BusinessDesigner`）** 或管理员可见。非授权用户即便看到并点击，cap4 服务端 AOP 也会拦截，安全由服务端兜底。

## 无侵入实现

不改动 A8 任何源码/JSP/JS。走平台官方的 **`extend/js`** 机制：把 JS 放到
`webapps/seeyon/extend/js/<视图名>/` 下，平台经 `ExtendJavascriptInteceptor` + `common_footer.jsp` 自动注入。

- 视图名：`personalAffair/message/messageCenter`
- 唯一代码文件：`webapp/extend/js/personalAffair/message/messageCenter/nkwarn-warnbtn.js`
- **纯前端**：权限判断复用平台 `callBackendMethod` / `$.ctx.CurrentUser`，模板→表单反查、本表触发查询都用现成的 ajaxStub 网关。**不需要 pluginCfg.xml、不占 category 号、不动数据库。**

## 关键技术点（便于日后维护）

| 环节 | 依赖 | 说明 |
|---|---|---|
| 注入 | `extend/js` + `common_footer.jsp` | 消息中心页 include 了 common_footer，机制生效 |
| 加按钮 | `$("#toolbar").attrObj("toolbarObj").addMenu({...})` | 工具栏组件公开 API，按钮元素 id=`nkWarnBtn_a` |
| 选中项 | 全局 `selected` + `#input_<id>` 隐藏域 | `c="t"` 为表单分类，隐藏域值=模板ID |
| 置灰 | 劫持全局 `changeCategory(id)` | 切换分类后刷新按钮状态 |
| 权限 | `callBackendMethod("capBizManager","getMembersByRole",loginAccount,"BusinessDesigner")` | 对比 `$.ctx.CurrentUser.id` |
| 模板→表单 | `templateManager.getCtpTemplate(tid).formAppId` | `ctp_template.FORM_APPID` = `cap_form_definition.ID` = CAP4 formId |
| 本表关系 | `cap4FormInnerBusinessManager.getFormInnerBusiness(formId)` → `relationList`+`triggerList` | 两者之和 >0 即"有"，对应左侧列表非空 |
| 跳转 | `cap4/business.do?method=bizConfigRelation&...&operationType=view|new` | 参数取自 cap4 SPA 自身的 `openRelation`/`trigger` 逻辑 |

## 部署

1. 右键 `部署到OA.bat` → **以管理员身份运行**。
   - A8 路径：**命令行参数 → 自动探测常见路径 → 都不中就提示你输入**，不用改脚本。
     也可 `部署到OA.bat "E:\你的\A8路径"`。
   - 会先做**部署前体检**（检查 `messageCenter.jsp` / `common_footer.jsp` / `ajaxStub.js` 是否存在），
     版本对不上会拦下来，避免拷了个寂寞。
2. **首次部署需重启一次 OA**（extend/js 新增目录要重启平台才识别）。
   > 之后只改此 js 内容、不新增目录，则不必重启，浏览器 `Ctrl+F5` 强刷即可。

> **为什么 bat 是纯英文的？**
> cmd 用「打开文件时的控制台代码页」解析整个 .bat，文件中途 `chcp` 无效。
> 带中文的 .bat 一旦控制台代码页不是 GBK（比如从 UTF-8 终端运行）就会被撕碎、
> 把中文当命令执行。纯 ASCII 是唯一与编码无关的写法，中文说明放在本 README。

### 换一台机器部署（如 117 测试服）

整个 `nkwarn` 文件夹拷过去 → 跑 `部署到OA.bat`（路径不同它会问你）→ 重启 OA。

**代码是可移植的**：formId / templateId 全部运行时反查（`getCtpTemplate`），
没有任何硬编码 ID，换实例不用改代码。

前提：目标机 A8 **版本一致**（体检会验），且消息中心左侧**配了表单模板类分类**
（`c="t"` 那种，如"发票登记单"）。若那台没配这类分类，按钮会一直置灰——
这是该实例的**数据/配置**问题，不是代码问题。

## 已知边界

- `bizConfigId` 省略（官方允许，等价"从表单管理进入"）。若发现新建触发保存有异常，可在 JS 里补上 formId→bizConfigId 的解析。
- 若某分类是"模板分类"(一个分类含多张模板)，取隐藏域里第一个模板ID对应的表单跳转。
- 跳转目标是 cap4 的"业务关系"独立页（右侧配置区），不含应用管理中心的左侧表单树/顶栏——因为 cap4 SPA 不支持按 formId 深链到完整外壳（产品能力限制）。
