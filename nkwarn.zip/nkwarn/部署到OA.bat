@echo off
setlocal EnableDelayedExpansion

rem ===================================================================
rem  nkwarn - Message Center "warning param" button - deployer
rem
rem  NOTE: This file is intentionally ASCII-only. A .bat containing
rem        Chinese text is parsed using the console codepage that was
rem        active when cmd OPENED the file; a mid-file "chcp" does NOT
rem        fix it. ASCII-only is the only encoding-proof option.
rem        Chinese docs live in README.md instead.
rem
rem  What it does : copies webapp\extend\js\**  ->  <A8>\ApacheJetspeed\
rem                 webapps\seeyon\extend\js\**      (pure new file,
rem                 no A8 source is modified)
rem  Usage        : right-click -> Run as administrator
rem                 or:  bat "E:\path\to\A8"
rem  A8 path      : command-line arg  ->  common defaults  ->  ask you
rem ===================================================================

echo.
echo   ======== nkwarn : deploy "warning param" button ========
echo.

set "SRC=%~dp0webapp\extend\js"
if not exist "%SRC%\" (
    echo   [ERROR] Source folder not found: %SRC%
    echo           Keep this .bat next to the "webapp" folder.
    goto END
)

rem ---------- 1) locate A8 root ----------
set "SEEYON=%~1"
if not "%SEEYON%"=="" goto CHECK

for %%P in ("D:\Seeyon\A8" "C:\Seeyon\A8" "E:\Seeyon\A8" "D:\Seeyon" "C:\Seeyon") do (
    if exist "%%~P\ApacheJetspeed\webapps\seeyon\" (
        set "SEEYON=%%~P"
        goto CHECK
    )
)

:ASK
echo   Could not auto-detect the A8 install root.
echo   Enter the A8 root folder ^(the one containing "ApacheJetspeed"^)
echo   example:  E:\Seeyon\A8
set /p "SEEYON=A8 root: "
if "%SEEYON%"=="" goto ABORT

:CHECK
set "SEEYON=%SEEYON:"=%"
if not exist "%SEEYON%\ApacheJetspeed\webapps\seeyon\" (
    echo.
    echo   [!] No ApacheJetspeed\webapps\seeyon under:
    echo       %SEEYON%
    echo.
    goto ASK
)

set "WEBAPP=%SEEYON%\ApacheJetspeed\webapps\seeyon"
set "DST=%WEBAPP%\extend\js"

rem ---------- 2) preflight : same version / structure ? ----------
echo   A8 root : %SEEYON%
echo.
echo   --- preflight ---

set "PREFLIGHT_OK=1"

if exist "%WEBAPP%\WEB-INF\jsp\personalAffair\message\messageCenter.jsp" (
    echo   [ OK ] target page  WEB-INF\jsp\personalAffair\message\messageCenter.jsp
) else (
    echo   [FAIL] messageCenter.jsp NOT found - different version? button will NOT work
    set "PREFLIGHT_OK=0"
)

if exist "%WEBAPP%\WEB-INF\jsp\common\common_footer.jsp" (
    echo   [ OK ] inject hook  WEB-INF\jsp\common\common_footer.jsp
) else (
    echo   [FAIL] common_footer.jsp NOT found - extend/js injection unavailable
    set "PREFLIGHT_OK=0"
)

if exist "%WEBAPP%\ajaxStub.js" (
    echo   [ OK ] ajax gateway ajaxStub.js
) else (
    echo   [WARN] ajaxStub.js NOT found - role check / lookup may fail
)

if exist "%WEBAPP%\extend\js\" (
    echo   [ OK ] extend\js already exists
) else (
    echo   [INFO] extend\js will be created ^(first use of this mechanism^)
)

if "%PREFLIGHT_OK%"=="0" (
    echo.
    echo   Preflight FAILED. Deploying anyway will most likely do nothing.
    set /p "GO=Continue anyway? (y/N): "
    if /i not "!GO!"=="y" goto ABORT
)

rem ---------- 3) confirm before touching anything ----------
echo.
echo   --- about to copy ---
echo   from: %SRC%
echo     to: %DST%
echo.
echo   Check the A8 root above is the RIGHT instance before continuing.
set /p "GO2=Proceed? (y/N): "
if /i not "%GO2%"=="y" goto ABORT

rem ---------- 4) copy ----------
echo.
echo   --- copying ---

robocopy "%SRC%" "%DST%" /E /NFL /NDL /NJH /NJS /NP
if %ERRORLEVEL% GEQ 8 (
    echo.
    echo   [FAIL] robocopy exit code %ERRORLEVEL% - copy incomplete.
    echo          If "access denied": re-run as administrator.
    goto END
)

set "TARGET=%DST%\personalAffair\message\messageCenter\nkwarn-warnbtn.js"
if exist "%TARGET%" (
    echo   [DONE] deployed:
    echo          %TARGET%
) else (
    echo   [FAIL] target file missing - check robocopy output above.
    goto END
)

echo.
echo   ============================================================
echo    NEXT STEP: restart OA once!
echo      extend/js is a NEW folder; the platform only picks it up
echo      after a restart.
echo      Then: login - "My Messages" - click "..." - the toolbar
echo      should show the new button.
echo.
echo    (Later, editing this .js content only - without adding new
echo     folders - needs NO restart; just Ctrl+F5 in the browser.)
echo   ============================================================
goto END

:ABORT
echo.
echo   Aborted. Nothing was changed.

:END
echo.
pause
endlocal
